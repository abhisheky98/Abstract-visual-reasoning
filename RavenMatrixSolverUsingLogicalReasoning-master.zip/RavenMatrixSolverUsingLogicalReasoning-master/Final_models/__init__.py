""" RAVEN benchmarking code

Author: Chi Zhang
Data: 05/14/2019
Contact: chi.zhang@ucla.edu
"""