# CS536_FinalProject
This work includes CS536 project code and notebooks for all baseline models and our proposed model.
We have proposed a novel model which combines Logic reasoning and CNNs to solve AVR problem on I-Raven dataset.
